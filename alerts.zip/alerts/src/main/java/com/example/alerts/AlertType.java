package com.example.alerts;

public enum AlertType {

    Normal,
    Warning,
    InputText,
    Progress

}
